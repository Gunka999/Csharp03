﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ThreadPoolS
{
    class Program
    {
        static void Main(string[] args)
        {
            ////ThreadPool.QueueUserWorkItem(X);
            ////Console.WriteLine("SDvfdsfsd");
            ////Console.WriteLine("Main thread exit");
            //Console.WriteLine(Y());
            Task task = new Task(CallMethod);
            task.Start();
            task.Wait();
            Console.ReadLine();
        }

        //static int Y()
        //{
        //    int x = 0;
        //    for (int i = 0; i < 10000; i++)
        //    {
        //        for (int z = 0; z < 100000000; z++)
        //        {
        //            x= i+z;
        //        }
        //    }
        //    return x;
        //}

        //public static void X(object state)
        //{
        //    Console.WriteLine("Hello");
        //}


        public static async void CallMethod()
        {
            string filePath = "D:\\test.txt";
            Task<int> total = ReadFile(filePath);
            Console.WriteLine("1 workkkkkk");
            Console.WriteLine("2 workkkkkk");
            Console.WriteLine("3 workkkkkk");
            Test();
            Console.WriteLine("4 workkkkkk");
            int len = await total;
            Console.WriteLine(len);
            Console.WriteLine("after new work 1");
        }

        public static void Test()
        {
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine(i + " test");
            }
        }

        static async Task<int> ReadFile(string file)
        {
            int length = 0;
            Console.WriteLine("Start file reading");
            using (StreamReader reader = new StreamReader(file))
            {
                string s = await reader.ReadToEndAsync();
                length = s.Length;
            }
            Console.WriteLine("reader end");
            return length;
        }
    }
}
