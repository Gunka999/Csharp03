﻿using MedicineCsharp03.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedicineCsharp03
{
    public partial class Login : Form
    {

        private readonly MedicineCsharp03Entities _db;
        public Login()
        {
            InitializeComponent();
            _db = new MedicineCsharp03Entities();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string email = txtEmailLogin.Text.Trim();
            string pass = txtPassLogin.Text.Trim();
            if (email == "" || pass =="")
            {
                MessageBox.Show("Fill all input", "Warning",
                 MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            User user = _db.Users.FirstOrDefault(u => u.Email == email);
            if (user ==null)
            {
                MessageBox.Show("Pls register", "Warning",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            Form1 form1 = new Form1();
            form1.ShowDialog();
            //this.Hide();

        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            //this.Hide();
            Register register = new Register(this);
            register.ShowDialog();
        }
    }
}
