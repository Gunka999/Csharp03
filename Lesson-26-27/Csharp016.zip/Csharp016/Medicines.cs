﻿using MedicineCsharp03.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedicineCsharp03
{
    public partial class Medicines : Form
    {
        private readonly MedicineCsharp03Entities _db;
        public Medicines()
        {
            InitializeComponent();
            _db = new MedicineCsharp03Entities();

        }

        private void Medicines_Load(object sender, EventArgs e)
        {
            cmbSelectType.DataSource = _db.Types.Where(t => t.Deleted == false).Select(t => new CB_Type
            {
                Id = t.Id,
                Name = t.Name
            }).ToArray();

            RefreshDgv();
            RefreshAllField();
        }

        private void RefreshDgv()
        {
            dtgvMedicine.DataSource = _db.Medicines.Where(m => m.IsDeleted == false).Select(x => new
            {
                x.Name,
                Type = x.Type.Name,
                x.Price,
                x.Amount
            }).ToList();
        }

        private void cmbSelectType_SelectedIndexChanged(object sender, EventArgs e)
        {
            int id = ((CB_Type)cmbSelectType.SelectedItem).Id;

            dtgvMedicine.DataSource = _db.Medicines.Where(m => m.IsDeleted == false && m.TypesId == id).Select(x => new
            {
                x.Name,
                Type = x.Type.Name,
                x.Price,
                x.Amount,
            }).ToList();
            RefreshAllField();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string name = txtMedicines.Text.Trim().ToLower();

            if (name == "")
            {
                MessageBox.Show("Pls filled", "Information",
             MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }

            int typeId = ((CB_Type)cmbSelectType.SelectedItem).Id;
            int amount = int.Parse(txtAmount.Value.ToString());
            double price = double.Parse(txtPrice.Value.ToString());

            Medicine medicine = _db.Medicines.FirstOrDefault(x => x.Name.ToLower() == name);

            if (medicine == null)
            {
                Medicine medicineDb = new Medicine
                {
                    Name = name,
                    TypesId = typeId,
                    Price = price,
                    Amount = amount
                };

                _db.Medicines.Add(medicineDb);
            }
            else
            {
                medicine.Amount = medicine.Amount+ amount;
                medicine.TypesId = typeId;
                medicine.Price = price;
            }
            _db.SaveChanges();

            MessageBox.Show("Success", "Information",
            MessageBoxButtons.OK, MessageBoxIcon.Information);

            RefreshDgv();
            RefreshAllField();
        }

        public void RefreshAllField()
        {
            txtMedicines.Text = "";
            txtAmount.Value = 0;
            txtPrice.Value = 0;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string name = txtMedicines.Text.Trim().ToLower() ;
            Medicine medicine = _db.Medicines.FirstOrDefault(x => x.Name.ToLower() == name);
            if (medicine !=null)
            {
                medicine.IsDeleted = true;
                _db.SaveChanges();
                RefreshDgv();
                RefreshAllField();
                MessageBox.Show("Deleted", "Deleted",
             MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            MessageBox.Show("This medicineis not exist", "Deleted",
      MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void dtgvMedicine_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            RefreshAllField();
            string name = dtgvMedicine.Rows[e.RowIndex].Cells["Name"].Value.ToString();
            Medicine medicine = _db.Medicines.FirstOrDefault(m => m.Name == name);
            txtMedicines.Text = name;
            txtAmount.Value = medicine.Amount;
            txtPrice.Value = decimal.Parse(medicine.Price.ToString());
            cmbSelectType.SelectedIndex = cmbSelectType.FindString(medicine.Type.Name);

        }
    }
}
