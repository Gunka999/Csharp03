﻿using MedicineCsharp03.Extensions;
using MedicineCsharp03.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedicineCsharp03
{
    public partial class Register : Form
    {
        private readonly MedicineCsharp03Entities _db;
        private readonly Form _login;
        public Register(Form login)
        {
            InitializeComponent();
            _login = login;
            _db = new MedicineCsharp03Entities();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text.Trim();
            string fullname = txtFullname.Text.Trim();
            string pass = txtPass.Text.Trim();
            string repead = txtRepeatPass.Text.Trim();

            if (!(IsValid(email, fullname, pass, repead)))
            {
                MessageBox.Show("ERROR", "Warning",
                   MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            bool emailInDb = _db.Users.Any(x => x.Email == email);

            if (emailInDb)
            {
                MessageBox.Show("Email already exist", "Warning",
                  MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }



            User user = new User
            {
                Fullname = fullname,
                Password = pass/*Cryptography.Encrypt(pass)*/,
                Email = email,
                IsActive = true,
                IsDeleted = false,
                IsAdmin = false
            };
            _db.Users.Add(user);
            _db.SaveChanges();



            MessageBox.Show("Successfuly register", "Success",
                MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private bool IsValid(string email, string fullname, string password, string checkPass)
        {
            if (email == "" || fullname == "" || password == "" || checkPass == "")
            {
                MessageBox.Show("Fill all input!", "Warning",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (!(email.Contains("@")))
            {
                return false;
            }

            if (password != checkPass)
            {
                MessageBox.Show("Please repead passwod correctly!", "Warning",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            return true;
        }

        private void Register_FormClosing(object sender, FormClosingEventArgs e)
        {
            _login.ShowDialog();
        }
    }
}
