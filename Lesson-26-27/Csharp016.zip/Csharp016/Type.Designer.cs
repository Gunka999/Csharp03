﻿namespace MedicineCsharp03
{
    partial class Type
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtTypeAdd = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAddType = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtTypeAdd
            // 
            this.txtTypeAdd.Location = new System.Drawing.Point(50, 47);
            this.txtTypeAdd.Name = "txtTypeAdd";
            this.txtTypeAdd.Size = new System.Drawing.Size(229, 20);
            this.txtTypeAdd.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(53, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Type Name";
            // 
            // btnAddType
            // 
            this.btnAddType.BackColor = System.Drawing.Color.Olive;
            this.btnAddType.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnAddType.Location = new System.Drawing.Point(50, 108);
            this.btnAddType.Name = "btnAddType";
            this.btnAddType.Size = new System.Drawing.Size(229, 39);
            this.btnAddType.TabIndex = 2;
            this.btnAddType.Text = "Add";
            this.btnAddType.UseVisualStyleBackColor = false;
            this.btnAddType.Click += new System.EventHandler(this.btnAddType_Click);
            // 
            // Type
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(304, 205);
            this.Controls.Add(this.btnAddType);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtTypeAdd);
            this.Name = "Type";
            this.Text = "Type";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtTypeAdd;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnAddType;
    }
}