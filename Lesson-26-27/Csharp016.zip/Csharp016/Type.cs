﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MedicineCsharp03.Model;

namespace MedicineCsharp03
{
    public partial class Type : Form
    {
        private readonly MedicineCsharp03Entities _db;
        public Type()
        {
            InitializeComponent();
            _db = new MedicineCsharp03Entities();

        }

        private void btnAddType_Click(object sender, EventArgs e)
        {
            string typeName = txtTypeAdd.Text.Trim();
            if (typeName =="")
            {
                MessageBox.Show("ERROR", "Warning",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;

            }
            if (_db.Types.Any(x=>x.Name==typeName))
            {
                MessageBox.Show("Bu ad var", "Warning",
                  MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            MedicineCsharp03.Model.Type test = new MedicineCsharp03.Model.Type
            {
                Name = typeName
            };

            _db.Types.Add(test);
            _db.SaveChanges();



            MessageBox.Show("Successfuly added", "Success",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();

        }
    }
}
