﻿using MedicineCsharp03.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedicineCsharp03
{
    public partial class TypeDelete : Form
    {
        private readonly MedicineCsharp03Entities _db;
        public TypeDelete()
        {
            InitializeComponent();
            _db = new MedicineCsharp03Entities();
        }

        private void btnDeleteType_Click(object sender, EventArgs e)
        {
            int id = ((CB_Type)cmbDeleteType.SelectedItem).Id;
            MedicineCsharp03.Model.Type type = _db.Types.Find(id);
            type.Deleted = true;
            _db.SaveChanges();

            MessageBox.Show("Successfuly delete", "Deleted",
              MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();

        }

        private void TypeDelete_Load(object sender, EventArgs e)
        {
            cmbDeleteType.DataSource=_db.Types.Where(t=>t.Deleted==false).Select(t=>new CB_Type{ 
            Id=t.Id,
            Name=t.Name
            }).ToArray();
        }
    }
}
