﻿using Csharp03EF.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Csharp03EF
{
    public partial class Form1 : Form
    {
        private readonly Csharp03Entities db;
        public Form1()
        {
            InitializeComponent();
            db = new Csharp03Entities();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            cmbcountry.DataSource = db.Countries.Select(x => x.Name).ToList();
        }

        private void cmbcountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            string country = cmbcountry.Text;
            if (!string.IsNullOrEmpty(country))
            {
                Country countryresult = db.Countries.FirstOrDefault(x => x.Name == country);
                if (countryresult.Cities.Count ==0)
                {
                    MessageBox.Show("nulldir");
                }
                cmbCity.DataSource = countryresult.Cities.Select(x => x.Name).ToList();
            }
        }
    }
}

